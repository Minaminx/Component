
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) Nginx, Inc.
 */


#ifndef _NGINX_H_INCLUDED_
#define _NGINX_H_INCLUDED_


#define nginx_version      3000002	/* 修改版本号 */
#define NGINX_VERSION      "3.0.2"	/* 修改版本号 */
#define NGINX_VER          "Nanqinlang/" NGINX_VERSION	/* 修改软件信息 */

#ifdef NGX_BUILD
#define NGINX_VER_BUILD    NGINX_VER " (" NGX_BUILD ")"
#else
#define NGINX_VER_BUILD    NGINX_VER
#endif

#define NGINX_VAR          "Nanqinlang"	/* 修改软件信息 */
#define NGX_OLDPID_EXT     ".oldbin"


#endif /* _NGINX_H_INCLUDED_ */
